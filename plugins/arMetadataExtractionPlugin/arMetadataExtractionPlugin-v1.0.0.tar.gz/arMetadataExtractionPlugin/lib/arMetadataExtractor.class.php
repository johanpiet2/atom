<?php

/*
 * This file is part of the Access to Memory (AtoM) software.
 *
 * Access to Memory (AtoM) is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Access to Memory (AtoM) is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Access to Memory (AtoM).  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Metadata extraction service for digital objects
 *
 * @package    arMetadataExtractionPlugin
 * @subpackage lib
 * @author     Johan Pieterse <pieterse.johan3@gmail.com>
 */
class arMetadataExtractor
{
    protected $settings = [];
    protected $logger;
    
    public function __construct()
    {
        $this->loadSettings();
        $this->logger = sfContext::getInstance()->getLogger();
    }
    
    /**
     * Load plugin settings from database
     */
    protected function loadSettings()
    {
        $settingNames = [
            'metadata_extraction_enabled',
            'extract_exif',
            'extract_iptc',
            'extract_xmp',
            'overwrite_title',
            'overwrite_description',
            'auto_generate_keywords',
            'extract_gps_coordinates',
            'add_technical_metadata'
        ];
        
        foreach ($settingNames as $name) {
            $setting = QubitSetting::getByName($name);
            $this->settings[$name] = $setting ? $setting->getValue(['sourceCulture' => true]) : false;
        }
    }
    
    /**
     * Process a digital object and extract metadata
     *
     * @param QubitDigitalObject $digitalObject
     * @return bool Success status
     */
    public function processDigitalObject(QubitDigitalObject $digitalObject)
    {
        if (!$this->settings['metadata_extraction_enabled']) {
            return false;
        }
        
        $filePath = $digitalObject->getAbsolutePath();
        
        if (!$filePath || !file_exists($filePath)) {
            $this->logger->warning('Metadata extraction: File not found at ' . $filePath);
            return false;
        }
        
        // Extract metadata using existing arEmbeddedMetadataParser
        $metadata = $this->extractMetadata($filePath);
        
        if (!$metadata) {
            return false;
        }
        
        // Get the information object
        $informationObject = $digitalObject->getInformationObject();
        
        if (!$informationObject) {
            $this->logger->warning('Metadata extraction: No information object linked to digital object');
            return false;
        }
        
        // Apply metadata to information object
        $this->applyMetadata($informationObject, $digitalObject, $metadata);
        
        return true;
    }
    
    /**
     * Extract metadata from file
     *
     * @param string $filePath
     * @return array|null
     */
    protected function extractMetadata($filePath)
    {
        if (!class_exists('arEmbeddedMetadataParser')) {
            $this->logger->error('arEmbeddedMetadataParser class not found');
            return null;
        }
        
        try {
            $rawMetadata = arEmbeddedMetadataParser::extract($filePath);
            
            if (!$rawMetadata) {
                return null;
            }
            
            return $this->normalizeMetadata($rawMetadata);
        } catch (Exception $e) {
            $this->logger->error('Metadata extraction failed: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Normalize raw metadata into structured format
     *
     * @param array $rawMetadata
     * @return array
     */
    protected function normalizeMetadata($rawMetadata)
    {
        $metadata = [
            'title' => null,
            'description' => null,
            'creator' => null,
            'date' => null,
            'keywords' => [],
            'gps' => null,
            'technical' => [],
            'rights' => null
        ];
        
        $norm = $rawMetadata['_norm'] ?? [];
        
        // Title (priority: XMP > IPTC > EXIF)
        $metadata['title'] = $norm['title'] ?? $rawMetadata['ObjectName'] ?? $rawMetadata['ImageDescription'] ?? null;
        
        // Description (priority: XMP > IPTC > EXIF)
        $metadata['description'] = $norm['description'] ?? $rawMetadata['Caption-Abstract'] ?? null;
        
        // Creator/Artist
        $metadata['creator'] = $norm['creator'] ?? $rawMetadata['By-line'] ?? $rawMetadata['Artist'] ?? null;
        
        // Date
        if (isset($norm['createDate'])) {
            $metadata['date'] = $this->parseDate($norm['createDate']);
        } elseif (isset($rawMetadata['DateTimeOriginal'])) {
            $metadata['date'] = $this->parseDate($rawMetadata['DateTimeOriginal']);
        }
        
        // Keywords
        if (isset($rawMetadata['Subject'])) {
            $metadata['keywords'] = is_array($rawMetadata['Subject']) 
                ? $rawMetadata['Subject'] 
                : array_map('trim', explode(',', $rawMetadata['Subject']));
        } elseif (isset($rawMetadata['Keywords'])) {
            $metadata['keywords'] = is_array($rawMetadata['Keywords'])
                ? $rawMetadata['Keywords']
                : array_map('trim', explode(',', $rawMetadata['Keywords']));
        }
        
        // GPS coordinates
        if (isset($rawMetadata['GPSLatitude'], $rawMetadata['GPSLongitude'])) {
            $metadata['gps'] = [
                'latitude' => $rawMetadata['GPSLatitude'],
                'longitude' => $rawMetadata['GPSLongitude']
            ];
        }
        
        // Technical metadata
        $technicalFields = [
            'Make', 'Model', 'FocalLength', 'FNumber', 
            'ExposureTime', 'ISO', 'ImageWidth', 'ImageHeight',
            'ColorSpace', 'WhiteBalance', 'Flash', 'LensModel'
        ];
        
        foreach ($technicalFields as $field) {
            if (isset($rawMetadata[$field])) {
                $metadata['technical'][$field] = $rawMetadata[$field];
            }
        }
        
        // Rights/Copyright
        $metadata['rights'] = $norm['rights'] ?? $rawMetadata['Copyright'] ?? null;
        
        return $metadata;
    }
    
    /**
     * Parse date string into standardized format
     *
     * @param string $dateString
     * @return string|null
     */
    protected function parseDate($dateString)
    {
        try {
            // Try common EXIF format first
            $date = DateTime::createFromFormat('Y:m:d H:i:s', $dateString);
            
            if (!$date) {
                // Try ISO format
                $date = new DateTime($dateString);
            }
            
            return $date ? $date->format('Y-m-d') : null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Apply extracted metadata to information object
     *
     * @param QubitInformationObject $informationObject
     * @param QubitDigitalObject $digitalObject
     * @param array $metadata
     */
    protected function applyMetadata($informationObject, $digitalObject, $metadata)
    {
        // Title
        if ($metadata['title'] && $this->shouldUpdateField($informationObject->getTitle(), 'title')) {
            $informationObject->setTitle($metadata['title']);
            $this->logger->info('Updated title from metadata: ' . $metadata['title']);
        }
        
        // Description/Scope and Content
        if ($metadata['description'] && $this->shouldUpdateField($informationObject->getScopeAndContent(), 'description')) {
            $informationObject->setScopeAndContent($metadata['description']);
            $this->logger->info('Updated scope and content from metadata');
        }
        
        // Creator
        if ($metadata['creator']) {
            $this->addCreator($informationObject, $metadata['creator']);
        }
        
        // Creation date
        if ($metadata['date']) {
            $this->addCreationDate($informationObject, $metadata['date']);
        }
        
        // Keywords as subject access points
        if (!empty($metadata['keywords'])) {
            $this->addSubjectAccessPoints($informationObject, $metadata['keywords']);
        }
        
        // GPS coordinates
        if ($metadata['gps'] && $this->settings['extract_gps_coordinates']) {
            $this->setGpsCoordinates($digitalObject, $metadata['gps']);
        }
        
        // Technical metadata
        if (!empty($metadata['technical']) && $this->settings['add_technical_metadata']) {
            $this->addTechnicalMetadata($informationObject, $metadata['technical']);
        }
        
        // Rights statement
        if ($metadata['rights']) {
            $this->addRightsStatement($informationObject, $metadata['rights']);
        }
        
        // Auto-generate keywords if enabled
        if ($this->settings['auto_generate_keywords']) {
            $generatedKeywords = $this->generateKeywords($metadata['technical']);
            if (!empty($generatedKeywords)) {
                $this->addSubjectAccessPoints($informationObject, $generatedKeywords);
            }
        }
        
        // Save changes
        $informationObject->save();
        $this->logger->info('Metadata extraction completed for object ID: ' . $informationObject->id);
    }
    
    /**
     * Determine if a field should be updated
     *
     * @param string $currentValue
     * @param string $fieldType
     * @return bool
     */
    protected function shouldUpdateField($currentValue, $fieldType)
    {
        $currentValue = trim($currentValue);
        
        // Check overwrite settings
        if ($fieldType === 'title' && $this->settings['overwrite_title']) {
            return true;
        }
        
        if ($fieldType === 'description' && $this->settings['overwrite_description']) {
            return true;
        }
        
        // Only update if empty or very short placeholder
        return empty($currentValue) || strlen($currentValue) <= 3;
    }
    
    /**
     * Add creator to information object
     *
     * @param QubitInformationObject $informationObject
     * @param string $creatorName
     */
    protected function addCreator($informationObject, $creatorName)
    {
        try {
            // Search for existing actor
            $criteria = new Criteria();
            $criteria->add(QubitActorI18n::AUTHORIZED_FORM_OF_NAME, $creatorName);
            $criteria->addJoin(QubitActor::ID, QubitActorI18n::ID);
            $actor = QubitActor::getOne($criteria);
            
            if (!$actor) {
                // Create new actor
                $actor = new QubitActor();
                $actor->setAuthorizedFormOfName($creatorName);
                $actor->setEntityTypeId(QubitTerm::PERSON_ID);
                $actor->save();
                $this->logger->info('Created new actor: ' . $creatorName);
            }
            
            // Check if relation exists
            $criteria = new Criteria();
            $criteria->add(QubitRelation::SUBJECT_ID, $actor->id);
            $criteria->add(QubitRelation::OBJECT_ID, $informationObject->id);
            $criteria->add(QubitRelation::TYPE_ID, QubitTerm::CREATION_ID);
            
            if (!QubitRelation::getOne($criteria)) {
                // Create relation
                $relation = new QubitRelation();
                $relation->setSubjectId($actor->id);
                $relation->setObjectId($informationObject->id);
                $relation->setTypeId(QubitTerm::CREATION_ID);
                $relation->save();
                
                // Also create event for context area
                $event = new QubitEvent();
                $event->setObjectId($informationObject->id);
                $event->setActorId($actor->id);
                $event->setTypeId(QubitTerm::CREATION_ID);
                $event->save();
                
                $this->logger->info('Added creator relation: ' . $creatorName);
            }
        } catch (Exception $e) {
            $this->logger->error('Failed to add creator: ' . $e->getMessage());
        }
    }
    
    /**
     * Add creation date to information object
     *
     * @param QubitInformationObject $informationObject
     * @param string $date
     */
    protected function addCreationDate($informationObject, $date)
    {
        try {
            // Check if creation date event exists
            $criteria = new Criteria();
            $criteria->add(QubitEvent::OBJECT_ID, $informationObject->id);
            $criteria->add(QubitEvent::TYPE_ID, QubitTerm::CREATION_ID);
            
            $existingEvent = QubitEvent::getOne($criteria);
            
            if (!$existingEvent) {
                $event = new QubitEvent();
                $event->setObjectId($informationObject->id);
                $event->setTypeId(QubitTerm::CREATION_ID);
                $event->setDate($date);
                $event->save();
                $this->logger->info('Added creation date: ' . $date);
            }
        } catch (Exception $e) {
            $this->logger->error('Failed to add creation date: ' . $e->getMessage());
        }
    }
    
    /**
     * Add subject access points from keywords
     *
     * @param QubitInformationObject $informationObject
     * @param array $keywords
     */
    protected function addSubjectAccessPoints($informationObject, $keywords)
    {
        foreach ($keywords as $keyword) {
            $keyword = trim($keyword);
            if (empty($keyword)) {
                continue;
            }
            
            try {
                // Check if term exists
                $criteria = new Criteria();
                $criteria->add(QubitTerm::TAXONOMY_ID, QubitTaxonomy::SUBJECT_ID);
                $criteria->add(QubitTermI18n::NAME, $keyword);
                $criteria->addJoin(QubitTerm::ID, QubitTermI18n::ID);
                
                $term = QubitTerm::getOne($criteria);
                
                if (!$term) {
                    // Create new term
                    $term = new QubitTerm();
                    $term->setTaxonomyId(QubitTaxonomy::SUBJECT_ID);
                    $term->setName($keyword);
                    $term->save();
                    $this->logger->info('Created new subject term: ' . $keyword);
                }
                
                // Check if relation exists
                $criteria = new Criteria();
                $criteria->add(QubitObjectTermRelation::OBJECT_ID, $informationObject->id);
                $criteria->add(QubitObjectTermRelation::TERM_ID, $term->id);
                
                if (!QubitObjectTermRelation::getOne($criteria)) {
                    // Create relation
                    $relation = new QubitObjectTermRelation();
                    $relation->setObjectId($informationObject->id);
                    $relation->setTermId($term->id);
                    $relation->save();
                    $this->logger->info('Added subject access point: ' . $keyword);
                }
            } catch (Exception $e) {
                $this->logger->error('Failed to add subject access point: ' . $e->getMessage());
            }
        }
    }
    
    /**
     * Set GPS coordinates on digital object
     *
     * @param QubitDigitalObject $digitalObject
     * @param array $gps
     */
    protected function setGpsCoordinates($digitalObject, $gps)
    {
        try {
            // Set latitude property
            $latProperty = $digitalObject->getPropertyByName('latitude');
            if (empty($latProperty->objectId)) {
                $latProperty = new QubitProperty();
                $latProperty->objectId = $digitalObject->id;
                $latProperty->editable = true;
                $latProperty->name = 'latitude';
            }
            $latProperty->value = $gps['latitude'];
            $latProperty->save();
            
            // Set longitude property
            $lonProperty = $digitalObject->getPropertyByName('longitude');
            if (empty($lonProperty->objectId)) {
                $lonProperty = new QubitProperty();
                $lonProperty->objectId = $digitalObject->id;
                $lonProperty->editable = true;
                $lonProperty->name = 'longitude';
            }
            $lonProperty->value = $gps['longitude'];
            $lonProperty->save();
            
            $this->logger->info('Set GPS coordinates: ' . $gps['latitude'] . ', ' . $gps['longitude']);
        } catch (Exception $e) {
            $this->logger->error('Failed to set GPS coordinates: ' . $e->getMessage());
        }
    }
    
    /**
     * Add technical metadata to physical characteristics
     *
     * @param QubitInformationObject $informationObject
     * @param array $technical
     */
    protected function addTechnicalMetadata($informationObject, $technical)
    {
        $sections = [];
        
        // Camera information
        if (isset($technical['Make'], $technical['Model'])) {
            $sections[] = 'Camera: ' . $technical['Make'] . ' ' . $technical['Model'];
        }
        
        // Lens information
        if (isset($technical['LensModel'])) {
            $sections[] = 'Lens: ' . $technical['LensModel'];
        }
        
        // Shooting settings
        $settings = [];
        if (isset($technical['FocalLength'])) {
            $settings[] = 'Focal Length: ' . $technical['FocalLength'];
        }
        if (isset($technical['FNumber'])) {
            $settings[] = 'Aperture: f/' . $technical['FNumber'];
        }
        if (isset($technical['ExposureTime'])) {
            $settings[] = 'Shutter Speed: ' . $technical['ExposureTime'];
        }
        if (isset($technical['ISO'])) {
            $settings[] = 'ISO: ' . $technical['ISO'];
        }
        
        if (!empty($settings)) {
            $sections[] = 'Settings: ' . implode(', ', $settings);
        }
        
        // Image properties
        if (isset($technical['ImageWidth'], $technical['ImageHeight'])) {
            $sections[] = 'Dimensions: ' . $technical['ImageWidth'] . ' × ' . $technical['ImageHeight'] . ' pixels';
        }
        
        if (!empty($sections)) {
            $currentPhysical = $informationObject->getPhysicalCharacteristics();
            $newMetadata = "Technical Metadata:\n" . implode("\n", $sections);
            
            if ($currentPhysical) {
                // Remove existing technical metadata section if present
                $currentPhysical = preg_replace('/\nTechnical Metadata:.*$/s', '', $currentPhysical);
                $informationObject->setPhysicalCharacteristics($currentPhysical . "\n\n" . $newMetadata);
            } else {
                $informationObject->setPhysicalCharacteristics($newMetadata);
            }
            
            $this->logger->info('Added technical metadata');
        }
    }
    
    /**
     * Add rights statement to information object
     *
     * @param QubitInformationObject $informationObject
     * @param string $rights
     */
    protected function addRightsStatement($informationObject, $rights)
    {
        $currentRights = $informationObject->getAccessConditions();
        
        if (empty($currentRights)) {
            $informationObject->setAccessConditions($rights);
            $this->logger->info('Added rights statement: ' . $rights);
        }
    }
    
    /**
     * Generate keywords from technical metadata
     *
     * @param array $technical
     * @return array
     */
    protected function generateKeywords($technical)
    {
        $keywords = [];
        
        // Camera brand keywords
        if (isset($technical['Make'])) {
            $make = strtolower(trim($technical['Make']));
            $brands = ['canon', 'nikon', 'sony', 'olympus', 'fujifilm', 'pentax', 'panasonic', 'leica'];
            $mobile = ['huawei', 'samsung', 'apple', 'google', 'xiaomi', 'oneplus'];
            
            if (in_array($make, $brands)) {
                $keywords[] = ucfirst($make) . ' Photography';
            } elseif (in_array($make, $mobile)) {
                $keywords[] = 'Mobile Photography';
            }
        }
        
        // Focal length based keywords
        if (isset($technical['FocalLength'])) {
            $focalLength = (float) preg_replace('/[^0-9.]/', '', $technical['FocalLength']);
            if ($focalLength <= 35) {
                $keywords[] = 'Wide Angle Photography';
            } elseif ($focalLength >= 85 && $focalLength < 200) {
                $keywords[] = 'Telephoto Photography';
            } elseif ($focalLength >= 200) {
                $keywords[] = 'Super Telephoto Photography';
            }
        }
        
        // ISO based keywords
        if (isset($technical['ISO'])) {
            $iso = (int) $technical['ISO'];
            if ($iso >= 1600) {
                $keywords[] = 'High ISO Photography';
            } elseif ($iso <= 200) {
                $keywords[] = 'Low Light Photography';
            }
        }
        
        // Always add
        $keywords[] = 'Digital Photography';
        
        return array_unique($keywords);
    }
}
