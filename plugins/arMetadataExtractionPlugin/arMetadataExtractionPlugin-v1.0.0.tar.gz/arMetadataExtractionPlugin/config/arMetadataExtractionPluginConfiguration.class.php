<?php

/*
 * This file is part of the Access to Memory (AtoM) software.
 *
 * Access to Memory (AtoM) is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Access to Memory (AtoM) is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Access to Memory (AtoM).  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * arMetadataExtractionPlugin configuration.
 *
 * @package    arMetadataExtractionPlugin
 * @subpackage config
 * @author     Johan Pieterse <pieterse.johan3@gmail.com>
 */
class arMetadataExtractionPluginConfiguration extends sfPluginConfiguration
{
    public function initialize()
    {
        // Register event listeners
        $this->dispatcher->connect('digital_object.post_create', [$this, 'extractMetadata']);
        
        // Add plugin-specific settings
        $this->addPluginSettings();
    }
    
    /**
     * Extract metadata when a digital object is created
     */
    public function extractMetadata(sfEvent $event)
    {
        $digitalObject = $event->getSubject();
        
        if ($digitalObject instanceof QubitDigitalObject) {
            $extractor = new arMetadataExtractor();
            $extractor->processDigitalObject($digitalObject);
        }
    }
    
    /**
     * Add plugin-specific settings to AtoM
     */
    protected function addPluginSettings()
    {
        // Define default settings
        $settings = [
            'metadata_extraction_enabled' => true,
            'extract_exif' => true,
            'extract_iptc' => true,
            'extract_xmp' => true,
            'overwrite_title' => false,
            'overwrite_description' => false,
            'auto_generate_keywords' => true,
            'extract_gps_coordinates' => true,
            'add_technical_metadata' => true,
        ];
        
        foreach ($settings as $name => $default) {
            if (null === QubitSetting::getByName($name)) {
                $setting = new QubitSetting();
                $setting->name = $name;
                $setting->value = $default;
                $setting->save();
            }
        }
    }
}
